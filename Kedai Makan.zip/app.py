# DAFTAR MENU DAN HARGA
menu_makanan = {
    "1. Nasi Goreng": 15000,
    "2. Tinutuan": 15000,
    "3. Gorengan": 2000   # Per 1 buah
}

menu_minuman = {
    "4. Kopi": 5000,
    "5. Es Teh": 5000,
    "6. Nutrisari": 5000
}

# FUNGSI UTAMA
def kasir_kedai():
    print("=" * 40)
    print("📝 KASIR KEDEI MAKAN")
    print("=" * 40)

    # TAMPILKAN MENU
    print("\n🍜 MAKANAN:")
    for nama, harga in menu_makanan.items():
        print(f"{nama} - Rp {harga:,}")

    print("\n🥤 MINUMAN:")
    for nama, harga in menu_minuman.items():
        print(f"{nama} - Rp {harga:,}")

    print("-" * 40)

    total_bayar = 0
    pesanan = []

    # PROSES PESANAN
    while True:
        pilih = input("\nMasukkan nomor menu (atau ketik 'selesai'): ")

        if pilih.lower() == 'selesai':
            break

        ditemukan = False
        # CEK MAKANAN
        for nama, harga in menu_makanan.items():
            if nama.startswith(pilih + "."):
                jumlah = int(input(f"Berapa banyak {nama[3:]} yang dibeli? "))
                subtotal = harga * jumlah
                pesanan.append(f"{nama[3:]} x{jumlah} = Rp {subtotal:,}")
                total_bayar += subtotal
                print(f"✅ Ditambahkan: {nama[3:]}")
                ditemukan = True
                break

        # CEK MINUMAN
        if not ditemukan:
            for nama, harga in menu_minuman.items():
                if nama.startswith(pilih + "."):
                    jumlah = int(input(f"Berapa banyak {nama[3:]} yang dibeli? "))
                    subtotal = harga * jumlah
                    pesanan.append(f"{nama[3:]} x{jumlah} = Rp {subtotal:,}")
                    total_bayar += subtotal
                    print(f"✅ Ditambahkan: {nama[3:]}")
                    ditemukan = True
                    break
        
        if not ditemukan:
            print("❌ Nomor menu tidak ada, coba lagi.")

    # CETAK STRUK & CARA PEMBAYARAN
    print("\n" + "=" * 40)
    print("🧾 STRUK PEMBELIAN")
    print("=" * 40)

    if len(pesanan) == 0:
        print("Tidak ada pesanan.")
    else:
        for item in pesanan:
            print(item)

    print("-" * 40)
    print(f"TOTAL BAYAR : Rp {total_bayar:,}")
    print("=" * 40)

    # 👇 FITUR PEMBAYARAN BARU 👇
    print("\n💳 CARA PEMBAYARAN:")
    print("1. Bayar dengan DANA  : 081314347426")
    print("2. Bayar dengan GO-PAY: 081314347426")
    print("3. Bayar Tunai di Kasir")
    print("-" * 40)

    pilih_bayar = input("\nPilih cara pembayaran (1/2/3): ")

    if pilih_bayar == "1":
        print(f"\n👉 Silakan transfer ke nomor DANA: 081314347426")
    elif pilih_bayar == "2":
        print(f"\n👉 Silakan transfer ke nomor GO-PAY: 081314347426")
    elif pilih_bayar == "3":
        print("\n👉 Silakan bayar langsung kepada kasir ya.")
    else:
        print("\nPilihan tidak valid, silakan bayar di kasir.")

    # UCAPAN PENUTUP
    print("\n" + "=" * 40)
    print("🙏 TERIMA KASIH SUDAH BERKUNJUNG 🙏")
    print("   Semoga Makanannya Enak & Puas!   ")
    print("=" * 40)

# JALANKAN PROGRAM
kasir_kedai()
  